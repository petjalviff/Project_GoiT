from pathlib import Path

new_dir=Path("e:/Projects/Project_GoiT/Tier1_gIt/modul_6/assigments/grade6")
new_dir.mkdir(parents=True) # --> make directory
# new_dir.rmdir()