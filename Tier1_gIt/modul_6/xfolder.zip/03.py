import shutil

# print(shutil.get_archive_formats())


shutil.make_archive("first archive", "zip", "e:/Projects/Project_GoiT/Tier1_gIt/modul_6/" )
shutil.unpack_archive("first archive.zip","e:/Projects/Project_GoiT/Tier1_gIt/1111")


# make_archive - створии архів
# unpack_archive - розпакувати архів